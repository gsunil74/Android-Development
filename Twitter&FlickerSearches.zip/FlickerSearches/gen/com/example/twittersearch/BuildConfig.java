/** Automatically generated file. DO NOT MODIFY */
package com.example.twittersearch;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}